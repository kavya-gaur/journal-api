journals = [
        {
            "title":"hi",
            "description":"hsaa"
        },
        {
            "title":"hi",
            "description":"hsaa"
        },
        {
            "title":"hi",
            "description":"hsaa"
        },
        {
            "title":"hi",
            "description":"hsaa"
        }
]


module.exports = journals;